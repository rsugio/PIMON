import com.sap.gateway.ip.core.customdev.util.Message

import java.nio.charset.StandardCharsets

Message executeGroovyScript(Message message) {

    final String QUERY_PARAM_FUNCTION = 'function'
    
    String httpQuery = message.headers['CamelHttpQuery'] as String
    httpQuery = (httpQuery) ? URLDecoder.decode(httpQuery, StandardCharsets.UTF_8.name()) : ''
    String functionName = httpQuery.tokenize('&').find { it.tokenize('=')[0] == QUERY_PARAM_FUNCTION }?.minus("$QUERY_PARAM_FUNCTION=") ?: 'processData'
    
    Script script = new GroovyShell().parse(message.getBody(Reader))
    return script."${functionName}"(message)

}