import com.sap.gateway.ip.core.customdev.util.Message
import org.apache.commons.csv.CSVFormat
import org.apache.commons.csv.CSVPrinter
import java.time.Month
import java.time.format.TextStyle

Message processData(Message message) {
    
    def months = [Month.values()*.value, Month.values()*.getDisplayName(TextStyle.FULL, Locale.ENGLISH)].transpose()

    StringBuilder builder = new StringBuilder()
    CSVPrinter csv = new CSVPrinter(builder, CSVFormat.DEFAULT)
    csv.printRecords(months)
    csv.close(true)
    message.body = builder.toString()

    return message

}