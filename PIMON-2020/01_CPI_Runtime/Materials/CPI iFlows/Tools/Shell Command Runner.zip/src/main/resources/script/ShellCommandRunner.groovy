import com.sap.gateway.ip.core.customdev.util.Message
import groovy.io.GroovyPrintStream
import org.apache.karaf.shell.api.console.Session
import org.apache.karaf.shell.api.console.SessionFactory
import org.osgi.framework.BundleContext
import org.osgi.framework.FrameworkUtil
import org.osgi.framework.ServiceReference

import java.nio.charset.StandardCharsets


Message executeOsShellCommand(Message message) {

    final long COMMAND_EXEC_TIMEOUT_MS = 60000

    String command = getCommand(message.headers['CamelHttpQuery'] as String)

    if (command) {

        try {
            Process process = command.execute()
            process.waitForOrKill(COMMAND_EXEC_TIMEOUT_MS)
            message.body = (process.exitValue()) ? process.err.text : process.in.text
        } catch (IOException | IllegalThreadStateException e) {
            message.body = "Error while executing command\nCommand: ${command}\nError: ${e.message}\n"
        }

    } else {
        message.body = "Error: Command has not been provided, check query parameter\n"
    }

    message.setHeader('Content-Type', 'text/plain')

    return message

}


Message executeOsgiShellCommand(Message message) {

    String command = getCommand(message.headers['CamelHttpQuery'] as String)

    if (command) {

        try {

            ByteArrayOutputStream out = new ByteArrayOutputStream()
            ByteArrayOutputStream err = new ByteArrayOutputStream()

            BundleContext context = FrameworkUtil.getBundle(Message).bundleContext
            ServiceReference sessionFactoryServiceReference = context.getServiceReference(SessionFactory)
            SessionFactory sessionFactory = (SessionFactory) context.getService(sessionFactoryServiceReference)
            Session session = sessionFactory.create(new ByteArrayInputStream(), new GroovyPrintStream(out, true), new GroovyPrintStream(err, true))
            session.execute(command)
            message.body = out.toString()
            session.close()
            context.ungetService(sessionFactoryServiceReference)

        } catch (SecurityException | IllegalStateException | IllegalArgumentException e) {
            message.body = "Error while executing command\nCommand: ${command}\nError: ${e.message}\n"
        }

    } else {
        message.body = "Error: Command has not been provided, check query parameter\n"
    }

    message.setHeader('Content-Type', 'text/plain')

    return message

}


private String getCommand(String httpQuery) {

    final String QUERY_PARAM_COMMAND = 'command'
    
    httpQuery = (httpQuery) ? URLDecoder.decode(httpQuery, StandardCharsets.UTF_8.name()) : ''
    return httpQuery.tokenize('&').find { it.tokenize('=')[0] == QUERY_PARAM_COMMAND }?.minus("$QUERY_PARAM_COMMAND=")

}