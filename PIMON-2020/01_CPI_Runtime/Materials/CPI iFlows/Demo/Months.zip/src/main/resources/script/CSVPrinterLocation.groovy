import com.sap.gateway.ip.core.customdev.util.Message
import org.apache.commons.csv.CSVPrinter

Message processData(Message message) {

    message.body = CSVPrinter.protectionDomain.codeSource.location.toString()

    return message

}