import com.sap.gateway.ip.core.customdev.util.Message

import java.nio.charset.StandardCharsets

Message filterByCountry(Message message) {

    Map<String, String> queryParams = [:]
    String httpQuery = message.headers['CamelHttpQuery'] as String
    httpQuery = (httpQuery) ? URLDecoder.decode(httpQuery, StandardCharsets.UTF_8.name()) : ''
    httpQuery.tokenize('&').each { httpQueryParam ->
        List<String> queryParam = httpQueryParam.tokenize('=')
        queryParams.put(queryParam[0], queryParam[1])
    }

    List<String> countries = queryParams['country']?.tokenize(',')
    String filterQuery = countries.collect { country -> "Country eq '$country'" }.join(' or ')

    message.setProperty('FilterQueryOption', filterQuery)

    return message

}